be sure to have an upload directory with write permission for apache user (www-data, nobody, ...).
However sudo chmod -R 777 upload should fix permission issue on server side.