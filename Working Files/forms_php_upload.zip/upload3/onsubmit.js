var formId = document.getElementById("formUpload");
var firstnameId = document.getElementById("firstname");
var lastnameId = document.getElementById("lastname");

formId.onsubmit = progressBar;